-- If you want to create your own custom player settings, 
-- make a copy of this script and add it to your StarterPlayer object

local module = {}

module.UseDefaultAnimations = false -- force incoming players to use default avatar animations, not custom animations

return module